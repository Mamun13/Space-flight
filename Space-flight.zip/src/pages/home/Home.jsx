import React from 'react'
import SpaceFlight from '../../Components/flight/SpaceFlight'

const Home = () => {
  return (
    <>
      <SpaceFlight/>
    </>
  )
}

export default Home